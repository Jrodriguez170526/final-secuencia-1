<?php

$nombre_fichero = __DIR__."/basededatos2.sqlite3";

?>