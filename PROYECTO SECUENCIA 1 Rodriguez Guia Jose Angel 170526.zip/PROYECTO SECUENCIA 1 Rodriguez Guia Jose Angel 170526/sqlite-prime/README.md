# Ejemplo básico de PHP

## Instalar

1. Bajar esta carpeta y almacenarla en su equipo en la ruta:
"C:\xampp\htdocs"

2. Arrancar el servidor Apache de XAMP

3. Ejecutar poniendo la ruta :"http://localhost/sqlite-alumnos/php/leer-alumnos.php" en su navegador

4. Probarlo usando ThunderClient de VSODE